package controller;

import model.Cidade;

import java.math.BigDecimal;
import java.math.BigInteger;

public class CidadeController {
    private final Cidade cidade;

    public CidadeController(Cidade cidade){
        this.cidade = cidade;
    }

    public void update(){
        cidade.setConsumo(view.readConsumo);
        cidade.setPopulacao(view.readPopulacao);
    }

    public void vazaoDia(){
        cidade.getVazaoDia(view.readVazaoDia);
    }

    public void vazaoSec(){
        cidade.getVazaoSegundo(view.readVazaoSec);
    }



}
