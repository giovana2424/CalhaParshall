package model.Service;

import model.Cidade;

public class Service {

    Cidade cidade;

}
