import controller.CidadeController;
import model.CalhaParshall;
import model.Cidade;
import model.service.Service;
import view.View;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

        Cidade cidade = new Cidade();
        View view = new View();
        Service service = new Service();
        CidadeController cidadeController = new CidadeController(cidade, view,service);

        cidadeController.update();
        cidadeController.print();
        cidadeController.print2();
    }
}